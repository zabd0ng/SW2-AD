"""layout practice
"""

import datetime
import sys
import line, line_sat, line_holi
from get_timeline import GetTime

from PyQt5.QtWidgets import *
from station_info import *

class Example(QWidget):
    """simple window class"""

    def __init__(self):
        super().__init__()

        self.init_ui()

    def init_ui(self):
        label1 = QLabel("역명")
        label2 = QLabel("호선")
        label3 = QLabel("상/하행")

        self.lineedit_station = QLineEdit()
        self.combo_line = QComboBox()
        self.combo_updown = QComboBox()
        self.showtext = QTextEdit()


        self.showtext.setReadOnly(1)

        self.combo_line.addItems(lineNoList)
        self.combo_updown.addItems(["상행", "하행"])

        self.button_find = QPushButton("보기")
        self.button_find.clicked.connect(self.showResult)

        hbox1 = QHBoxLayout()

        hbox1.addWidget(label1)
        hbox1.addWidget(self.lineedit_station)
        hbox1.addWidget(label2)
        hbox1.addWidget(self.combo_line)
        hbox1.addWidget(label3)
        hbox1.addWidget(self.combo_updown)
        hbox1.addWidget(self.button_find)

        vbox1 = QVBoxLayout()
        vbox1.addLayout(hbox1)
        vbox1.addWidget(self.showtext)


        self.setLayout(vbox1)

        self.move(300, 150)
        self.setWindowTitle('지하철 도착 정보')
        self.show()


    def showResult(self):

        self.month = str(datetime.datetime.now().month)
        self.day = str(datetime.datetime.now().day)
        self.date = self.month + '.' + self.day

        self.station = input(self.lineedit_station.text())
        self.no = input(self.combo_line.currentText())
        self.direction = input(self.combo_updown.currentText())

        while True:
            try:
                if datetime.datetime.now().weekday() == 5:
                    Info = line_sat.Line(self.station, self.no, self.direction)
                elif datetime.datetime.now().weekday() == 6 or self.date in holiday_list:
                    Info = line_holi.Line(self.station, self.no, self.direction)
                else:
                    Info = line.Line(self.station, self.no, self.direction)

            except:
                self.showtext.append('역 정보가 틀립니다. 다시 확인해주세요')
            else:
                break

        if self.station in except_stations and self.no != '05호선':
            timeline = Info.noInfoStations()
            sys.exit()
        elif self.no == '01호선':
            url = Info.line01()
        elif self.no == '05호선':
            url = Info.line05()
        else:
            url = Info.lineN()

        print(url)

        Info = GetTime(url, self.station, self.no, self.direction)

        res = Info.time()
        self.showtext.append(res)




if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = Example()
    sys.exit(app.exec_())   # 이벤트루프 돎

