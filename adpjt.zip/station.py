import datetime
from sys import exit
from station_info import *
import line, line_sat, line_holi
from get_timeline import GetTime

month = str(datetime.datetime.now().month)
day = str(datetime.datetime.now().day)
date = month + '.' + day

station = input("역명: ").replace(" ", '')
no = input("호선:") + "호선"
direction = input("방향: ").replace(" ", '')

while True:
    try:
        if datetime.datetime.now().weekday() == 5:
            Info = line_sat.Line(station, no, direction)
        elif datetime.datetime.now().weekday() == 6 or date in holiday_list:
            Info = line_holi.Line(station, no, direction)
        else:
            Info = line.Line(station, no, direction)

    except:
        print('올바른 값이 입력되지 않았습니다')
        station = input("역명: ").replace(" ", '')
        no = input("호선:") + "호선"
        direction = input("방향: ").replace(" ", '')
    else:
        break

if station in except_stations and no != '05호선':
    timeline = Info.noInfoStations()
    exit()
elif no == '01호선':
    url = Info.line01()
elif no == '05호선':
    url = Info.line05()
else:
    url = Info.lineN()

print(url)

Info = GetTime(url, station, no, direction)

res = Info.time()
print(res)

