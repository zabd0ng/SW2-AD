import datetime
from station_info import *
from line import Line
import requests
from bs4 import BeautifulSoup

station = input("역명: ")
no = input("호선:") + "호선"
print(no)
Info = Line(station, no)

if station in except_stations:
    timeline = Info.noInfoStations()
    exit()
elif no == '01호선':
    url = Info.line01()
elif no == '05호선':
    url = Info.line05()
else:
    url = Info.lineN()

print(url)
response = requests.get(url)

html = response.text
soup = BeautifulSoup(html, 'html.parser')

opportunity = soup.select_one('tr:nth-of-type(2) > td').get('rowspan')
print(opportunity)

hour = datetime.datetime.now().hour # - 시간만 따오기
minute = datetime.datetime.now().minute # - 분만 따오기
print(datetime.datetime.now().weekday()) #(0이 월요일, 6이 일요일)


timelist = soup.select('tr')[3:]
for time in timelist:
    t = time.get_text().replace('\n', '')
    if hour <= int(t[0:2]) and minute <= int(t[3:5]):
        print(t)
        break
