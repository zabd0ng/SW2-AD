import sys

from PyQt5.QtCore import Qt, QCoreApplication
from PyQt5.QtGui import QPainter, QPen, QColor, QFont
from PyQt5.QtWidgets import QWidget, QApplication, QPushButton

# 참고 링크: https://blog.jiktong.kr/2246
# http://www.gisdeveloper.co.kr/?p=8360


class MainWindow(QWidget):
    def __init__(self, no):
        super().__init__()
        #self.initUI()
        self.pos_x = int(self.width() / 2)
        self.no = no
        # self.direction = 1
        # self.speed = 0

    # def initUI(self):
    #     # 윈도우 설정
    #     self.setGeometry(500, 200, 500, 500)  # x, y, w, h
    #     self.setWindowTitle('지하철 노선도')
    #
    #     # 창닫기 버튼
    #     btn = QPushButton('Quit', self)
    #     btn.move(int(self.width() / 2 + 160), int(self.height() / 2 + 220))
    #     btn.resize(btn.sizeHint())
    #     btn.clicked.connect(QCoreApplication.instance().quit)

    def paintEvent(self, e):
        qp = QPainter()
        qp.begin(self)
        self.draw_Lines(qp)
        self.draw_point(qp)
        self.draw_direction(qp)
        qp.end()

    def draw_Lines(self, qp):  # 8호선
        red = Qt.red
        linePen = QPen(red, 3.5, Qt.SolidLine)
        qp.setPen(linePen)

        global x
        x = 10
        qp.drawLine(6 * x, 15 * x, 44 * x, 15 * x)   # x1, y1, x2, y2  # 1행
        qp.drawLine(6 * x, 25 * x, 44 * x, 25 * x)   # 2행    # 가로 길이 = 38 * x
        qp.drawLine(6 * x, 35 * x, 44 * x, 35 * x)   # 3행
        qp.drawLine(44 * x, 15 * x, 44 * x, 25 * x)  # 1열    # 세로 길이 = 10 * x
        qp.drawLine(6 * x, 25 * x, 6 * x, 35 * x)    # 2열

    def draw_point(self, qp):
        qp.setBrush(QColor(255, 85, 105))

        line8 = ['암사', '천호', '강동구청', '몽촌토성', '잠실', '석촌',
                 '산성', '복정', '장지', '문정', '가락시장', '송파',
                 '남한산성입구', '단대오거리', '신흥', '수진', '모란']

        global now_station
        global now_stationNum
        now_station = '모란'
        now_stationNum = -1
        for i in range(len(line8)):
            if now_station == line8[i]:
                now_stationNum = i

        if 0 <= now_stationNum < 6:
            qp.drawRect(int(10 + 6 * now_stationNum) * x, int(14.5 * x), 12, 12)
        elif 6 <= now_stationNum < 12:
            qp.drawRect(int(10 + 6 * (now_stationNum - 6)) * x, int(24.5 * x), 12, 12)
        elif 12 <= now_stationNum <= 16:
            qp.drawRect(int(11 + 7 * (now_stationNum - 12)) * x, int(34.5 * x), 12, 12)

        print(now_stationNum)

    def draw_direction(self, qp):
        now_direction = '하행'
        qp.setPen(QColor(0, 0, 0))
        qp.setFont(QFont('맑은 고딕', 14))
        if now_direction == '상행' or now_direction == '하행':
            qp.drawText(x, int(48.8 * x), '방향: ' + now_direction + ', 현재 역: ' + now_station)

        if now_stationNum == 0:
            if now_direction == '상행':
                pass
            elif now_direction == '하행':
                qp.drawText(7 * x, int(13.5 * x), '▶▶▶')
        elif 1 <= now_stationNum < 6:
            if now_direction == '상행':
                qp.drawText(int(11 + 5.5 * now_stationNum) * x, int(13.5 * x), '◀◀◀')
            elif now_direction == '하행':
                qp.drawText(int(11 + 5.5 * now_stationNum) * x, int(13.5 * x), '▶▶▶')
        elif 6 <= now_stationNum < 12:
            if now_direction == '상행':
                qp.drawText(int(8 + 5.9 * (now_stationNum - 6)) * x, int(23.5 * x), '▶▶▶')
            elif now_direction == '하행':
                qp.drawText(int(8 + 5.9 * (now_stationNum - 6)) * x, int(23.5 * x), '◀◀◀')
        elif 12 <= now_stationNum < 16:
            if now_direction == '상행':
                qp.drawText(int(8.5 + 7.2 * (now_stationNum - 12)) * x, int(33.5 * x), '◀◀◀')
            elif now_direction == '하행':
                qp.drawText(int(8.5 + 7.2 * (now_stationNum - 12)) * x, int(33.5 * x), '▶▶▶')
        elif now_stationNum == 16:
            if now_direction == '상행':
                qp.drawText(37 * x, int(33.5 * x), '◀◀◀')
            elif now_direction == '하행':
                pass


# if __name__ == '__main__':
#     app = QApplication(sys.argv)
#     mainWindow = MainWindow()
#     mainWindow.show()
#     sys.exit(app.exec_())
